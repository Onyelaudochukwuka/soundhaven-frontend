import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlay } from '@fortawesome/free-solid-svg-icons';
import { Track, Artist, Album } from '@/types';
import { deleteTrack, fetchArtists, fetchAlbums } from '../services/apiService';
import RenderEditCell from './RenderEditCell';

interface TracksTableProps {
  tracks: Track[];
  onDelete: (id: number) => void;
  onUpdate: (id: number, field: string, value: string) => void;
  onSelectTrack: (trackFilePath: string, trackIndex: number) => void;
  isEditing: boolean;
  setIsEditing: (isEditing: boolean) => void;
}

const TracksTable: React.FC<TracksTableProps> = ({ tracks, onDelete, onUpdate, onSelectTrack, isEditing, setIsEditing }) => {
  const [artists, setArtists] = useState<Artist[]>([]);
  const [albums, setAlbums] = useState<Album[]>([]);
  const [editCell, setEditCell] = useState<{ id: number, field: keyof Track } | null>(null);

  // Fetch artists and albums only once on component mount
  useEffect(() => {
    let isMounted = true;
    const loadArtistsAndAlbums = async () => {
      try {
        const [loadedArtists, loadedAlbums] = await Promise.all([fetchArtists(), fetchAlbums()]);
        if (isMounted) {
          setArtists(loadedArtists);
          setAlbums(loadedAlbums);
        }
      } catch (error) {
        console.error('Error fetching artists/albums:', error);
      }
    };
    loadArtistsAndAlbums();

    return () => {
      isMounted = false;
    };
  }, []);

  const handleDoubleClick = (track: Track, field: keyof Track) => {
    if (field === 'duration') return;
    setEditCell({ id: track.id, field });
    setIsEditing(true);
  };

  const handleDelete = async (id: number, event: React.MouseEvent) => {
    event.stopPropagation();
    await deleteTrack(id);
    onDelete(id);
  };

  return (
    <table className="min-w-full divide-y divide-gray-200">
      <thead className="bg-gray-50">
        <tr>
          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Play</th>
          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Title</th>
          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Artist</th>
          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Album</th>
          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Duration</th>
          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Delete</th>
        </tr>
      </thead>
      <tbody className="bg-white divide-y divide-gray-200">
        {tracks.map((track, index) => (
          <tr key={track.id}>
            <td>
              <button onClick={(e) => {
                e.stopPropagation();
                track.filePath && onSelectTrack(track.filePath, index);
              }}>
                <FontAwesomeIcon icon={faPlay} />
              </button>
            </td>
            {['name', 'artist', 'album', 'duration'].map((field) => (
              <RenderEditCell
                key={field}
                track={track}
                field={field as keyof Track}
                editCell={editCell}
                artists={artists}
                albums={albums}
                onDoubleClick={() => handleDoubleClick(track, field as keyof Track)}
                onUpdate={onUpdate}
              />
            ))}
            <td>
              <button onClick={(e) => handleDelete(track.id, e)}>X</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default TracksTable;
