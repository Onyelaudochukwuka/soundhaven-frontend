// components/Header.jsx
const Header = () => {
    return (
      <header className="text-center p-4">
        {/* Navigation, Search Bar, User Profile */}
      </header>
    );
  };
  
  export default Header;
  