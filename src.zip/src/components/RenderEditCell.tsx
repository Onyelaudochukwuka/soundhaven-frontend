import React, { useState, useEffect } from 'react';
import { Track, Artist, Album } from '@/types';
import Autocomplete from './Autocomplete';

interface RenderEditCellProps {
  track: Track;
  field: keyof Track;
  editCell: { id: number, field: keyof Track } | null;
  artists: Artist[];
  albums: Album[];
  onDoubleClick: () => void;
  onUpdate: (id: number, field: string, value: string) => void;
}

const RenderEditCellComponent: React.FC<RenderEditCellProps> = ({ track, field, editCell, artists, albums, onDoubleClick, onUpdate }) => {
  const [editValue, setEditValue] = useState('');

  useEffect(() => {
    if (editCell && editCell.id === track.id && editCell.field === field) {
      setEditValue(track[field]?.toString() ?? '');
    } else {
      setEditValue('');
    }
  }, [editCell, track, field]);

  const handleAutocompleteSelect = (selectedValue: string) => {
    if (editCell) {
      onUpdate(editCell.id, field, selectedValue);
    }
  };

  const handleBlur = () => {
    if (editCell) {
      onUpdate(editCell.id, field, editValue);
    }
  };

  const isEditing = editCell?.id === track.id && editCell.field === field;

  if (isEditing) {
    if (field === 'artist' || field === 'album') {
      const items = field === 'artist' ? artists.map(a => ({ id: a.id.toString(), name: a.name })) : albums.map(a => ({ id: a.id.toString(), name: a.name }));
      return (
        <Autocomplete
          items={items}
          onSelect={(item) => handleAutocompleteSelect(item.name)}
        />
      );
    } else {
      return (
        <input
          type="text"
          value={editValue}
          onChange={(e) => setEditValue(e.target.value)}
          onBlur={handleBlur}
          autoFocus
        />
      );
    }
  } else {
    return (
      <td onDoubleClick={onDoubleClick}>
        {field === 'album' ? track.album?.name ?? 'No Album' :
          field === 'artist' ? track.artist?.name ?? 'Unknown Artist' :
            track[field]?.toString() ?? ''}
      </td>
    );
  }
};

const RenderEditCell = React.memo(RenderEditCellComponent);

export default RenderEditCell;
